﻿using System.Collections.Generic;
using System.IO;
using AppointmentSchedulingSystem.ML; // Link to the class above
using AppointmentSchedulingSystem.Models;
using Microsoft.ML;

namespace AppointmentSchedulingSystem.ML
{
	public class MLTrainer
	{
		public static void Train()
		{
			var mlContext = new MLContext();

            // SIMPLE training data (History of patients)
            var data = new List<MLInput>
			{
                // Good Patients (High attendance, usually morning/mid-week)
                new MLInput { AttendedCount=6, MissedCount=0, Hour=10, DayOfWeek=1, Label=true },
				new MLInput { AttendedCount=4, MissedCount=1, Hour=9, DayOfWeek=2, Label=true },
                
                // "Risky" Patients (High missed count, late hours, weekends)
                new MLInput { AttendedCount=1, MissedCount=4, Hour=18, DayOfWeek=5, Label=false },
				new MLInput { AttendedCount=0, MissedCount=3, Hour=20, DayOfWeek=6, Label=false }
			};

			var trainingData = mlContext.Data.LoadFromEnumerable(data);

			// Create the Pipeline
			var pipeline = mlContext.Transforms
				.Concatenate("Features", "AttendedCount", "MissedCount", "Hour", "DayOfWeek")
				.Append(mlContext.BinaryClassification.Trainers.LbfgsLogisticRegression());

			// Train the model
			var model = pipeline.Fit(trainingData);

			// Save the model file to the main folder
			mlContext.Model.Save(model, trainingData.Schema, "DoctorPatientML.zip");
		}
	}
}