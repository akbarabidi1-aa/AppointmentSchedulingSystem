﻿using System.IO;
using AppointmentSchedulingSystem.Models;
using Microsoft.ML;

namespace AppointmentSchedulingSystem.ML
{
	public class MLPredictor
	{
		// This MUST match the name of the zip file created by MLTrainer
		private static string _modelPath = "DoctorPatientML.zip";
		private static PredictionEngine<MLInput, MLOutput> _predictionEngine;
		private static MLContext _mlContext = new MLContext();

		public static MLOutput Predict(MLInput input)
		{
			// If the engine isn't ready yet, load the model and create it
			if (_predictionEngine == null)
			{
				// Load the model from the .zip file
				ITransformer mlModel;

				// We wrap this in a try-catch in case the training hasn't run yet
				try
				{
					mlModel = _mlContext.Model.Load(_modelPath, out var modelInputSchema);
				}
				catch (FileNotFoundException)
				{
					// If model doesn't exist, return a default "safe" prediction (Probability 1.0 means "Will Attend")
					return new MLOutput { Prediction = true, Probability = 1.0f };
				}

				_predictionEngine = _mlContext.Model.CreatePredictionEngine<MLInput, MLOutput>(mlModel);
			}

			// Return the prediction
			return _predictionEngine.Predict(input);
		}
	}
}