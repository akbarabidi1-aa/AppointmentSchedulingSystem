﻿namespace AppointmentSchedulingSystem.Models
{
    public class MLInput
    {
        public float AttendedCount { get; set; }
        public float MissedCount {  get; set; }
        public  float Hour {  get; set; }
        public float DayOfWeek { get; set; }

        public bool Label { get; set; }
    }
}
