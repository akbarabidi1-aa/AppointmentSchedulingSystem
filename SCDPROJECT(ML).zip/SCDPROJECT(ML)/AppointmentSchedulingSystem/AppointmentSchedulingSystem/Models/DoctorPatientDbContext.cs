﻿using Microsoft.EntityFrameworkCore;

namespace AppointmentSchedulingSystem.Models
{
    // 1. MUST be "public"
    // 2. MUST be spelled "Doctor..." (not Dcotor)
    public class DoctorPatientDbContext : DbContext
    {
        public DoctorPatientDbContext(DbContextOptions<DoctorPatientDbContext> options) : base(options)
        {
        }

        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Patient> Patients { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
    }
}