﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AppointmentSchedulingSystem.Models
{
	[Table("Appointments")]
	public class Appointment
	{
		[Key]
		public int AppointmentID { get; set; }

		[Required]
		public int DoctorID { get; set; }

		[Required]
		public int PatientID { get; set; }

		public DateTime AppointmentDate { get; set; }

		public TimeSpan AppointmentTime { get; set; }

		public string Status { get; set; } // Ensure 'S' is capital

		// This must be a STRING. Do not use float/double for RiskLevel.
		public string? RiskLevel { get; set; }

		// Navigation Properties
		public virtual Doctor Doctor { get; set; }
		public virtual Patient Patient { get; set; }
	}
}