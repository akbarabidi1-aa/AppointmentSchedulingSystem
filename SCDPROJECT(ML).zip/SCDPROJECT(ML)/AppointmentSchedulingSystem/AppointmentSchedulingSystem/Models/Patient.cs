﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AppointmentSchedulingSystem.Models
{
    [Table("Patients")]
    public class Patient
    {
        public int PatientId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
