﻿namespace AppointmentSchedulingSystem.Models
{
    public class MLOutput
    {
        public bool Prediction {  get; set; }
        public float Probability { get; set;  }
    }
}
