﻿using AppointmentSchedulingSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace AppointmentSchedulingSystem.Controllers
{
    public class AccountController : Controller
    {
        private readonly DoctorPatientDbContext _db;

        // Constructor
        public AccountController(DoctorPatientDbContext db)
        {
            _db = db;
        }

        // GET: Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: Register
        [HttpPost]
        public IActionResult Register(Patient patient)
        {
            if (ModelState.IsValid)
            {
                _db.Patients.Add(patient);
                _db.SaveChanges();
                return RedirectToAction("Login");
            }
            return View(patient);
        }

        // GET: Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var patient = _db.Patients
                .FirstOrDefault(p => p.Email == email && p.Password == password);

            if (patient != null)
            {
                HttpContext.Session.SetInt32("PatientID", patient.PatientId);
                HttpContext.Session.SetString("PatientName", patient.Name);
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Invalid email or password";
            return View();
        }

        // Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}