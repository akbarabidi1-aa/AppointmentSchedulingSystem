﻿using AppointmentSchedulingSystem.Models;
using AppointmentSchedulingSystem.ML;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Collections.Generic;

namespace AppointmentSchedulingSystem.Controllers
{
	public class AppointmentController : Controller
	{
		private readonly DoctorPatientDbContext _db;

		public AppointmentController(DoctorPatientDbContext db)
		{
			_db = db;
		}

		// Step 1: Show list of doctors
		public IActionResult Doctors()
		{
			if (HttpContext.Session.GetInt32("PatientID") == null)
			{
				return RedirectToAction("Login", "Account");
			}

			var doctors = _db.Doctors.ToList();
			return View(doctors);
		}

		// Step 2: Show available slots
		public IActionResult Book(int id)
		{
			if (HttpContext.Session.GetInt32("PatientID") == null)
			{
				return RedirectToAction("Login", "Account");
			}

			ViewBag.DoctorId = id;
			var doctor = _db.Doctors.Find(id);
			ViewBag.DoctorName = doctor.Name;

			var slots = new List<DateTime>();
			DateTime today = DateTime.Today;

			// Generate slots for next 5 days
			for (int day = 0; day < 5; day++)
			{
				for (int hour = 9; hour < 17; hour++)
				{
					slots.Add(today.AddDays(day).AddHours(hour));
				}
			}

			return View(slots);
		}

		// Step 3: Confirm booking (WITH AI)
		[HttpPost]
		public IActionResult ConfirmBooking(int doctorId, DateTime slotTime)
		{
			int? patientId = HttpContext.Session.GetInt32("PatientID");

			if (patientId == null)
			{
				return RedirectToAction("Login", "Account");
			}

			// --- AI INTEGRATION ---

			// 1. Calculate History
			// Note: Ensure you use "Confirmed" (Capital C) if that's what you saved in DB
			int attended = _db.Appointments
				.Count(a => a.PatientID == patientId && a.Status == "Confirmed");

			int missed = _db.Appointments
				.Count(a => a.PatientID == patientId && a.Status == "Missed");

			// 2. Prepare Data
			var input = new MLInput
			{
				AttendedCount = attended,
				MissedCount = missed,
				Hour = slotTime.Hour,
				DayOfWeek = (float)slotTime.DayOfWeek
			};

			// 3. Get Prediction
			var prediction = MLPredictor.Predict(input);
			string calculatedRisk = "Low";

			if (prediction.Probability < 0.5)
			{
				calculatedRisk = "High";
				TempData["Warning"] = "⚠ AI Analysis: High risk of missing this appointment.";
			}
			else
			{
				TempData["Success"] = "✅ Appointment Booked Successfully!";
			}

			// 4. Save Appointment
			var appointment = new Appointment
			{
				DoctorID = doctorId,        // Capital D
				PatientID = (int)patientId, // Capital P
				AppointmentDate = slotTime.Date,
				AppointmentTime = slotTime.TimeOfDay,
				Status = "Pending",         // Capital S
				RiskLevel = calculatedRisk
			};

			_db.Appointments.Add(appointment);
			_db.SaveChanges();

			return RedirectToAction("MyAppointments");
		}

		// Step 4: List appointments
		public IActionResult MyAppointments()
		{
			int? patientId = HttpContext.Session.GetInt32("PatientID");
			if (patientId == null) return RedirectToAction("Login", "Account");

			// This is where the error likely happened
			var appointments = _db.Appointments
				.Include(a => a.Doctor)
				.Where(a => a.PatientID == patientId) // Capital P
				.OrderBy(a => a.AppointmentDate)
				.ToList();

			return View(appointments);
		}
	}
}