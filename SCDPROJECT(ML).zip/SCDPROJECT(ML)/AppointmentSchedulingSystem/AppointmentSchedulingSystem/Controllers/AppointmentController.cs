﻿using AppointmentSchedulingSystem.Models;
using AppointmentSchedulingSystem.ML; // <--- 1. IMPORT ML NAMESPACE
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Collections.Generic;

namespace AppointmentSchedulingSystem.Controllers
{
	public class AppointmentController : Controller
	{
		private readonly DoctorPatientDbContext _db;

		public AppointmentController(DoctorPatientDbContext db)
		{
			_db = db;
		}

		// Step 1: Show list of doctors
		public IActionResult Doctors()
		{
			if (HttpContext.Session.GetInt32("PatientID") == null)
			{
				return RedirectToAction("Login", "Account");
			}

			var doctors = _db.Doctors.ToList();
			return View(doctors);
		}

		// Step 2: Show available slots for a doctor
		public IActionResult Book(int id)
		{
			if (HttpContext.Session.GetInt32("PatientID") == null)
			{
				return RedirectToAction("Login", "Account");
			}

			ViewBag.DoctorId = id;
			var doctor = _db.Doctors.Find(id);
			ViewBag.DoctorName = doctor.Name;

			var slots = new List<DateTime>();
			DateTime today = DateTime.Today;

			for (int day = 0; day < 5; day++)
			{
				for (int hour = 9; hour < 17; hour++)
				{
					slots.Add(today.AddDays(day).AddHours(hour));
				}
			}

			return View(slots);
		}

		// Step 3: Confirm booking (WITH AI PREDICTION)
		[HttpPost]
		public IActionResult ConfirmBooking(int doctorId, DateTime slotTime)
		{
			int? patientId = HttpContext.Session.GetInt32("PatientID");

			if (patientId == null)
			{
				return RedirectToAction("Login", "Account");
			}


			// ====================================================
			// START AI INTEGRATION
			// ====================================================

			// 1. Calculate History (Count previous attended/missed)
			// Note: This relies on you manually updating status to "Confirmed" or "Missed" in SQL later
			int attended = _db.Appointments
				.Count(a => a.PatientId == patientId && a.status == "Confirmed");

			int missed = _db.Appointments
				.Count(a => a.PatientId == patientId && a.status == "Missed");

			// 2. Prepare Data for AI
			var input = new MLInput
			{
				AttendedCount = attended,
				MissedCount = missed,
				Hour = slotTime.Hour,
				DayOfWeek = (float)slotTime.DayOfWeek
			};

			// 3. Get Prediction
			var prediction = MLPredictor.Predict(input);
			string calculatedRisk = "Low";

			// 4. Set Message based on Probability
			// If Probability is LOW (< 0.5), AI thinks they might miss it.
			if (prediction.Probability < 0.5)
			{
				calculatedRisk = "High";
				TempData["Warning"] = "⚠ AI Analysis: Based on your history or this time slot, there is a risk you might miss this appointment.";
			}
			else
			{
				TempData["Success"] = "✅ Appointment Booked Successfully!";
			}

			// ====================================================
			// END AI INTEGRATION
			// ====================================================

			// 5. Save the Appointment
			var appointment = new Appointment
			{
				DoctorId = doctorId,   // Ensure Model uses DoctorID (Capital D)
				PatientId = (int)patientId, // Ensure Model uses PatientID (Capital P)
				AppointmentDate = slotTime.Date,
				AppointmentTime = slotTime.TimeOfDay,
				status = "Pending",// Default status
				RiskLevel = calculatedRisk
			};

			_db.Appointments.Add(appointment);
			_db.SaveChanges();

			return RedirectToAction("MyAppointments");
		}

		// Step 4: List patient appointments
		public IActionResult MyAppointments()
		{
			int? patientId = HttpContext.Session.GetInt32("PatientID");
			if (patientId == null) return RedirectToAction("Login", "Account");

			var appointments = _db.Appointments
				.Include(a => a.Doctor)
				.Where(a => a.PatientId == patientId) // Matches Model Capitalization
				.OrderBy(a => a.AppointmentDate)
				.ToList();

			return View(appointments);
		}
	}
}