﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http; // For Session
using Microsoft.EntityFrameworkCore; // For .Include()
using AppointmentSchedulingSystem.Models;
using System.Linq;
using Microsoft.Identity.Client;

namespace AppointmentSchedulingSystem.Controllers
{
    public class DoctorController : Controller
    {
        private readonly DoctorPatientDbContext _db;

        public DoctorController(DoctorPatientDbContext db)
        {
            _db = db;
        }
        public ActionResult Login()
        {
            return View();
        }
		[HttpPost]
		public IActionResult Login(string email, string password)
		{
			// 1. Guard Clause: Don't crash if fields are empty
			if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
			{
				ViewBag.Error = "Please enter both email and password";
				return View();
			}

			// 2. Find the doctor by EMAIL first (Ignoring Case & Spaces)
			// We use .Trim() to remove hidden spaces
			var doctor = _db.Doctors
				.AsEnumerable() // Pull to memory to perform safe string comparison
				.FirstOrDefault(d => d.Email != null &&
									 d.Email.Trim().ToLower() == email.Trim().ToLower());

			// 3. Check the PASSWORD
			if (doctor != null && doctor.Password == password)
			{
				// Success! Set Session
				HttpContext.Session.SetInt32("DoctorID", doctor.DoctorId);
				HttpContext.Session.SetString("DoctorName", doctor.Name);

				return RedirectToAction("Dashboard");
			}

			// 4. Failed
			ViewBag.Error = "Invalid email or password";
			return View();
		}
		public IActionResult Dashboard()
        {
			int? doctorId = HttpContext.Session.GetInt32("DoctorID");
			if (doctorId == null)
            {
                return RedirectToAction("Login");
            }
			var appointments = _db.Appointments
				.Include(a => a.Patient) // Include Patient Info so we can see who booked
				.Where(a => a.DoctorID == doctorId)
				.OrderBy(a => a.AppointmentDate)
				.ToList();

			return View(appointments);

		}
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

		public IActionResult CancelAppointment(int id)
		{
			// Check doctor login
			if (HttpContext.Session.GetInt32("DoctorID") == null) return RedirectToAction("Login");

			var appointment = _db.Appointments.Find(id);
			if (appointment != null)
			{
				appointment.Status = "Cancelled"; // Update status
				_db.SaveChanges();
			}
			return RedirectToAction("Dashboard");
		}

	}
}
