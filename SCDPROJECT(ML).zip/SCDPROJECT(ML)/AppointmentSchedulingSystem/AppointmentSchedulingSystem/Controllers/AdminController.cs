﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using AppointmentSchedulingSystem.Models;
using System.Linq;

namespace AppointmentSchedulingSystem.Controllers
{
	public class AdminController : Controller
	{
		private readonly DoctorPatientDbContext _db;

		public AdminController(DoctorPatientDbContext db)
		{
			_db = db;
		}

		// ==========================
		// 1. ADMIN LOGIN
		// ==========================
		public IActionResult Login()
		{
			return View();
		}

		[HttpPost]
		public IActionResult Login(string username, string password)
		{
			var admin = _db.Admins
				.FirstOrDefault(a => a.Username == username && a.Password == password);

			if (admin != null)
			{
				HttpContext.Session.SetInt32("AdminID", admin.AdminID);
				HttpContext.Session.SetString("AdminName", admin.Username);
				return RedirectToAction("Dashboard");
			}

			ViewBag.Error = "Invalid Admin Credentials";
			return View();
		}

		// ==========================
		// 2. ADMIN DASHBOARD
		// ==========================
		public IActionResult Dashboard()
		{
			if (HttpContext.Session.GetInt32("AdminID") == null)
			{
				return RedirectToAction("Login");
			}

			// Gather data for the dashboard
			ViewBag.TotalDoctors = _db.Doctors.Count();
			ViewBag.TotalPatients = _db.Patients.Count();
			ViewBag.TotalAppointments = _db.Appointments.Count();

			// Send list of Doctors to the view (so admin can manage them)
			var doctors = _db.Doctors.ToList();
			return View(doctors);
		}

		// ==========================
		// 3. ADD NEW DOCTOR
		// ==========================
		public IActionResult AddDoctor()
		{
			if (HttpContext.Session.GetInt32("AdminID") == null) return RedirectToAction("Login");
			return View();
		}

		[HttpPost]
		public IActionResult AddDoctor(Doctor doc)
		{
			if (ModelState.IsValid)
			{
				_db.Doctors.Add(doc);
				_db.SaveChanges();
				return RedirectToAction("Dashboard");
			}
			return View(doc);
		}

		// ==========================
		// 4. LOGOUT
		// ==========================
		public IActionResult Logout()
		{
			HttpContext.Session.Clear();
			return RedirectToAction("Login");
		}

		public IActionResult DeleteDoctor(int id)
		{
			if (HttpContext.Session.GetInt32("AdminID") == null) return
					RedirectToAction("Login");
			var doctor = _db.Doctors.Find(id);
			if(doctor != null)
			{
				_db.Doctors.Remove(doctor);
				_db.SaveChanges();
			}
			return RedirectToAction("Dashboard");
		}
	}
}